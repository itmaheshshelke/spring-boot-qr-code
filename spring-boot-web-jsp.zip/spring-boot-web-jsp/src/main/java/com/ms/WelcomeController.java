package com.ms;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

@Controller
public class WelcomeController {

	private static final Logger logger = LoggerFactory.getLogger(WelcomeController.class);

	private static final String QR_CODE_IMAGE_PATH = "./files/MyQRCode.png";

	

	@RequestMapping("/")
	public String welcome(Map<String, Object> model) {
		model.put("message", "Generate Qr Code Example");
		return "welcome";
	}

	@PostMapping("/generate-qr-code")
	public void generateQrCode(@ModelAttribute DataModel dataModel, HttpServletResponse response) {
		// Load file as Resource
		try {
			String data="";
			data=data+dataModel.getName();
			data=data+"\n"+dataModel.getValue();

			generateQRCodeImage(data, 350, 350, QR_CODE_IMAGE_PATH);
			
			
			response.setContentType("text/html");  
			PrintWriter out = response.getWriter();  

			response.setContentType("APPLICATION/OCTET-STREAM");   
			response.setHeader("Content-Disposition","attachment; filename=\"" + QR_CODE_IMAGE_PATH + "\"");   
			  
			FileInputStream fileInputStream = new FileInputStream(QR_CODE_IMAGE_PATH);  
			            
			int i;   
			while ((i=fileInputStream.read()) != -1) {  
			out.write(i);   
			}   
			fileInputStream.close();   
			out.close();   
			
			
		} catch (WriterException e) {
			logger.info("Could not generate QR Code, WriterException :: " + e.getMessage());
		} catch (IOException e) {
			logger.info("Could not generate QR Code, IOException :: " + e.getMessage());
		}

	}

	private static String generateQRCodeImage(String text, int width, int height, String filePath)
			throws WriterException, IOException {
		Path path=null;
		try {
			
			logger.info("generateQRCodeImage () stared :: ");
			QRCodeWriter qrCodeWriter = new QRCodeWriter();
			BitMatrix bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, width, height);

			 path = FileSystems.getDefault().getPath(filePath);
			MatrixToImageWriter.writeToPath(bitMatrix, "PNG", path);
			logger.info("generateQRCodeImage () End :: ");
			
		} catch (Exception e) {
			logger.info("Could not generate QR Code, WriterException :: " + e.getMessage());
		}
		
		return path.toString();
	}

}